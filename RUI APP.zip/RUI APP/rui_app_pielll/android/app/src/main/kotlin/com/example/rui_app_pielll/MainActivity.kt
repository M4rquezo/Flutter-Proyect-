package com.example.rui_app_pielll

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
